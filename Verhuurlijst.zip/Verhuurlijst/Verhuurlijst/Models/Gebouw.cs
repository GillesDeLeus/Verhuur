﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Verhuurlijst.Models
{
    public class Gebouw
    {
        [Key]
        public int Id { get; set; }
        public string Adres { get; set; }
        [Required]
        public string Straat { get; set; }
        [Required]
        public int Huisnummer { get; set; }
        [Required]
        public string Gemeente { get; set; }
        public string Verantwoordelijke { get; set; }
        public IList<Kamer> KamersPerGebouw { get; set; }
        public int? AantalKamers { get; set; } = 0;
        public int? AantalVrijeKamers { get; set; } = 0;
        [Required]
        public bool Fietsenstalling { get; set; }
        [Required]
        public int AantalGedeeldeKeukens { get; set; }
        [Required]
        public int AantalGedeeldeDouchen { get; set; }
    }
}
