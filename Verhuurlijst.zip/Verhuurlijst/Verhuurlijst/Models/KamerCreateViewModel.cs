﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Verhuurlijst.Models
{
    public class KamerCreateViewModel
    {
        [Display(Name = "Id")]
        public int Id { get; set; }
        [Display(Name = "Kammernummer")]
        [Required(ErrorMessage ="Kamernummer mag niet leeg zijn.")]
        public string Kamernummer { get; set; }
        [Display(Name = "Verhuurd")]
        public bool IsVerhuurd { get; set; }
        [Display(Name = "Contract")]
        public string ContractStatus { get; set; }
        [Display(Name = "Bemeubeld")]
        public bool IsBemeubeld { get; set; }
        [Display(Name = "Huurprijs")]
        public double HuurPrijs { get; set; }
        [Display(Name = "Vaste Kosten")]
        public double VasteKosten { get; set; }
        [Display(Name = "Waarborg")]
        public double Waarborg { get; set; }
        [Display(Name = "Kamertype")]
        public string KamerType { get; set; }
        [Display(Name = "Begindatum")]
        public string Begindatum { get; set; }
        [Display(Name = "Einddatum")]
        public string Einddatum { get; set; }
        [Display(Name = "Huurder")]
        public string Huurder { get; set; }
        [Display(Name = "Sanitair op kamer")]
        public bool SanitairOpKamer { get; set; }
        [Display(Name = "Kitchenette op kamer")]
        public bool KitchenetteOpKamer { get; set; }
        [Display(Name = "Internetaansluiting")]
        public bool InternetaansluitingOpKamer { get; set; }
        [Required(ErrorMessage = "Er moet een gebouw geselecteerd worden.")]
        [Display(Name = "Gebouwen")]
        public List<Gebouw> GebouwenLijst { get; set; }
        [Display(Name = "Verantwoordelijke")]
        public string Verantwoordelijke { get; set; }
    }
}
