﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Verhuurlijst.Core;

namespace Verhuurlijst.Models
{
    public class Gebouwen
    {
        public IList<Gebouw> GebouwenLijst { get; set; }

    }
}
