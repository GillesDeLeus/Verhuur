﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataTables;

namespace Verhuurlijst.Models
{
    public class EditorTestModel
    {
        public int Id { get; set; }
        public string Naam { get; set; }
        public string datum { get; set; }
    }
}
