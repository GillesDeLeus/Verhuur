﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Verhuurlijst.Models.Enums;
using DataTables;


namespace Verhuurlijst.Models
{
    public class Kamer
    {
        [Display(Name = "Id")]
        public int Id { get; set; }
        [Required]
        [Display(Name = "Kammernummer")]
        public string Kamernummer { get; set; }
        [Display(Name = "Verhuurd")]
        public bool IsVerhuurd { get; set; }
        [Display(Name = "Contract")]
        public string ContractStatus { get; set; }
        [Display(Name = "Bemeubeld")]
        public bool IsBemeubeld { get; set; }
        [Display(Name = "Huurprijs")]
        [Required]
        public int HuurPrijs { get; set; }
        [Display(Name = "Vaste Kosten")]
        [Required]
        public int VasteKosten { get; set; }
        [Display(Name = "Waarborg")]
        [Required]
        public int Waarborg { get; set; }
        [Display(Name = "Adres")]
        public string Adres { get; set; }
        [Display(Name = "GebouwId")]
        [Required]
        public int GebouwId { get; set; }
        [Display(Name = "Kamertype")]
        public string KamerType { get; set; }
        [Display(Name = "Begindatum")]
        public string Begindatum { get; set; }
        [Display(Name = "Einddatum")]
        public string Einddatum { get; set; }
        [Display(Name = "Huurder")]
        public string Huurder { get; set; }
        [Display(Name = "Sanitair op kamer")]
        public bool SanitairOpKamer { get; set; }
        [Display(Name = "Kitchenette op kamer")]
        public bool KitchenetteOpKamer { get; set; }
        [Display(Name = "Internetaansluiting")]
        public bool InternetaansluitingOpKamer { get; set; }
        [Display(Name = "Verantwoordelijke")]
        public string Verantwoordelijke { get; set; }

    }
}
