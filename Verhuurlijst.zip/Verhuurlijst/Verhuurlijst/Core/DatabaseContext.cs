﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Verhuurlijst.Models;

namespace Verhuurlijst.Core
{
    public class DatabaseContext: DbContext
    {
        public DbSet<Gebouw> Gebouwen { get; set; }
        public DbSet<Kamer> Kamers { get; set; }
        public DatabaseContext(DbContextOptions<DatabaseContext> options):base(options) {
        }

    }
}
