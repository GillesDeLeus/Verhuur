﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Verhuurlijst.Models;

namespace Verhuurlijst.Core
{
    interface IDatabaseContext
    {
        IList<Gebouw> Gebouwen { get; set; }
        IList<Kamer> Kamers { get; set; }

    }
}
