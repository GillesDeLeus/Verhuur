﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Verhuurlijst.Models;
using Verhuurlijst.Core;

namespace Verhuurlijst.Controllers
{
    public class HomeController : Controller
    {
            private readonly DatabaseContext _databaseContext;

            public HomeController(DatabaseContext database)
            {
                _databaseContext = database;
            }

        public IActionResult Index()
        {
            var gebouwen = _databaseContext.Gebouwen.ToList();
            return View(gebouwen);
        }
        public IActionResult Lijst()
        {
            var gebouwen = _databaseContext.Gebouwen.ToList();
            return View(gebouwen);
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Gebouw()
        {
            return View();
        }


    }
}
