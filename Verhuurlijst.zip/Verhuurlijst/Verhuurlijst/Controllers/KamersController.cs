﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Verhuurlijst.Core;
using Verhuurlijst.Models;
using DataTables;
using System.ComponentModel.DataAnnotations;

namespace Verhuurlijst.Controllers
    {
    public class KamersController : Controller
    {
        private readonly DatabaseContext _context;

        public KamersController(DatabaseContext context)
        {
            _context = context;
        }

        // GET: Kamers
        public async Task<IActionResult> Index()
        {
            var kamers = await _context.Kamers.ToListAsync();
            //List<Kamer> kamersPerGebouw = kamers.OrderBy(o => o.Adres).ToList();
            //List<Kamer> kamersKamernummer = kamersPerGebouw.OrderBy(o => o.Kamernummer).ToList();
            return View(kamers);
        }

        //GET : Kamers/AddOrEdit
        //GET : Kamers/AddOrEdit/5
        public async Task<IActionResult> AddOrEdit(int id = 0) { 
            if(id == 0)
            {
                ViewBag.gebouwen = _context.Gebouwen.ToList();
                return View(new Kamer());
            } else
            {
                var kamer = await _context.Kamers.FindAsync(id);
                if (kamer == null)
                {
                    return NotFound();
                }
                return View(kamer);
            }
        }
        // POST: Kamers/AddOrEdit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrEdit(int id, [Bind("Id, Kamernummer, KamerType, IsVerhuurd, ContractStatus, Begindatum, Einddatum, IsBemeubeld, HuurPrijs, VasteKosten, Waarborg, SanitairOpKamer, KitchenetteOpKamer, InternetaansluitingOpKamer, Huurder, Verantwoordelijke, GebouwId")] Kamer kamer)
        {
            if (ModelState.IsValid)
            {
                if (id == 0)
                {
                    kamer.GebouwId = int.Parse(Request.Form["GebouwId"]);
                    var gebouwen = await _context.Gebouwen.ToListAsync();
                    foreach (var item in gebouwen)
                    {
                        //var success = false;
                        //while (success) //zorgt ervoor dat als gebouw gevonden wordt, er niet verder wordt gezocht.
                        //{
                            if (kamer.GebouwId == item.Id)
                            {
                                kamer.Adres = item.Adres;
                                kamer.Verantwoordelijke = item.Verantwoordelijke;
                                //success = true;
                            }
                        //}

                    }
                    _context.Add(kamer);
                    await _context.SaveChangesAsync();
                }
                else
                {
                    try
                    {
                        var gebouwen = await _context.Gebouwen.ToListAsync();
                        foreach (var item in gebouwen)
                        {
                            if (kamer.GebouwId == item.Id)
                            {
                                kamer.Adres = item.Adres;
                                kamer.Verantwoordelijke = item.Verantwoordelijke;
                            }
                        }
                        _context.Update(kamer);
                        await _context.SaveChangesAsync();
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        if (!KamerExists(kamer.Id))
                        {
                            return NotFound();
                        }
                        else
                        {
                            throw;
                        }
                    }
                    catch (DbUpdateException /* ex */)
                    {
                        //Log the error (uncomment ex variable name and write a log.)
                        ModelState.AddModelError("", "Unable to save changes. " +
                            "Try again, and if the problem persists, " +
                            "see your system administrator.");
                    }
                }

                return Json(new { isValid = true, html = Helper.RenderRazorViewToString(this, "_KamerPartialView", _context.Kamers.ToList()) });
            }
            return Json(new { isValid = false, html = Helper.RenderRazorViewToString(this,"AddOrEdit", kamer) });
        }

        // GET: Kamers/Details/5
        public async Task<IActionResult> Details(int? id)
            {
                if (id == null)
                {
                    return NotFound();
                }

                var kamer = await _context.Kamers
                    .FirstOrDefaultAsync(m => m.Id == id);
                if (kamer == null)
                {
                    return NotFound();
                }

                return View(kamer);
            }

        // GET: Kamers/Create
        public IActionResult Create()
        {
            ViewBag.gebouwen = _context.Gebouwen.ToList();
            return View();
            //var vm = new KamerCreateViewModel();
            //vm.GebouwenLijst =  _context.Gebouwen.ToList();
            //return View(vm);
        }

        // POST: Kamers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id, Adres, Kamernummer,KamerType,IsVerhuurd, ContractStatus,Begindatum, Einddatum, IsBemeubeld,HuurPrijs,VasteKosten,Waarborg,SanitairOpKamer,KitchenetteOpKamer, InternetaansluitingOpKamer,Huurder,Verantwoordelijke, GebouwId")] Kamer kamer)
        {
            if (ModelState.IsValid)
            {
                kamer.GebouwId = int.Parse(Request.Form["GebouwId"]);
                var gebouwen =await _context.Gebouwen.ToListAsync();
                foreach (var item in gebouwen)
                {
                    
                    
                    if (kamer.GebouwId == item.Id)
                    {
                        kamer.Adres = item.Adres;
                        kamer.Verantwoordelijke = item.Verantwoordelijke;
                            
                    }
                    
                    
                }
                _context.Add(kamer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(kamer);
        }

        // GET: Kamers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var kamer = await _context.Kamers.AsNoTracking().FirstOrDefaultAsync(m => m.Id == id);
            if (kamer == null)
            {
                return NotFound();
            }
            return View(kamer);
        }

        // POST: Kamers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id, Kamernummer, KamerType, IsVerhuurd, ContractStatus, Begindatum, Einddatum, IsBemeubeld, HuurPrijs, VasteKosten, Waarborg, SanitairOpKamer, KitchenetteOpKamer, InternetaansluitingOpKamer, Huurder, Verantwoordelijke, GebouwId")] Kamer kamer)
        {
            if (id != kamer.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var gebouwen = await _context.Gebouwen.ToListAsync();
                    foreach (var item in gebouwen)
                    {
                        if (kamer.GebouwId == item.Id)
                        {
                            kamer.Adres = item.Adres;
                            kamer.Verantwoordelijke = item.Verantwoordelijke;
                        }
                    }
                    _context.Update(kamer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!KamerExists(kamer.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                catch (DbUpdateException /* ex */)
                {
                    //Log the error (uncomment ex variable name and write a log.)
                    ModelState.AddModelError("", "Unable to save changes. " +
                        "Try again, and if the problem persists, " +
                        "see your system administrator.");
                }
                return RedirectToAction(nameof(Index));
            }
            return View(kamer);
        }

        // GET: Kamers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var kamer = await _context.Kamers
                .FirstOrDefaultAsync(m => m.Id == id);
            if (kamer == null)
            {
                return NotFound();
            }

            return View(kamer);
        }

        // POST: Kamers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var kamer = await _context.Kamers.FindAsync(id);
            _context.Kamers.Remove(kamer);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool KamerExists(int id)
        {
            return _context.Kamers.Any(e => e.Id == id);
        }


    }
}
