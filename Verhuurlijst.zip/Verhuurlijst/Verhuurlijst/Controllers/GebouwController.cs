﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Verhuurlijst.Core;
using Verhuurlijst.Models;

namespace Verhuurlijst.Controllers
{
    public class GebouwController : Controller
    {
        private readonly DatabaseContext _context;

        public GebouwController(DatabaseContext context)
        {
            _context = context;
        }

        // GET: Gebouw
        public async Task<IActionResult> Index()
        {
            var gebouwen = _context.Gebouwen.ToList();
            foreach (var gebouw in gebouwen)
            {
                gebouw.AantalVrijeKamers = 0;
                gebouw.AantalKamers = 0;
                foreach (var kamer in _context.Kamers)
                {
                    if (kamer.GebouwId == gebouw.Id)
                    {
                        gebouw.KamersPerGebouw.Add(kamer);
                        gebouw.AantalKamers += 1;
                        if (kamer.IsVerhuurd == false)
                        {
                            gebouw.AantalVrijeKamers += 1;
                        }
                    }
                }
            }
            await _context.SaveChangesAsync();
            return View(await _context.Gebouwen.ToListAsync());
        }

        // GET: Gebouw/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            
            var gebouw = await _context.Gebouwen
                .FirstOrDefaultAsync(m => m.Id == id);
            gebouw.AantalKamers = 0;
            gebouw.AantalVrijeKamers = 0;
            foreach (var kamer in _context.Kamers)
            {
                if (kamer.GebouwId == id)
                {
                    gebouw.KamersPerGebouw.Add(kamer);
                    gebouw.KamersPerGebouw.Remove(kamer);
                    gebouw.AantalKamers += 1;
                    if (kamer.IsVerhuurd == false)
                    {
                        gebouw.AantalVrijeKamers += 1;
                    }
                }
            }
            if (gebouw == null)
            {
                return NotFound();
            }
            await _context.SaveChangesAsync();
            return View(gebouw);

        }

        // GET: Gebouw/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Gebouw/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Straat,Huisnummer,Gemeente,Verantwoordelijke,Fietsenstalling,AantalGedeeldeKeukens,AantalGedeeldeDouchen")] Gebouw gebouw)
        {
            if (ModelState.IsValid)
            {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append(gebouw.Straat);
                stringBuilder.Append(" ");
                stringBuilder.Append(gebouw.Huisnummer);
                gebouw.Adres = stringBuilder.ToString();
                _context.Add(gebouw);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(gebouw);
        }

        // GET: Gebouw/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var gebouw = await _context.Gebouwen.FindAsync(id);
            if (gebouw == null)
            {
                return NotFound();
            }
            return View(gebouw);
        }

        // POST: Gebouw/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Adres,Straat,Huisnummer,Gemeente,Verantwoordelijke,Fietsenstalling,AantalGedeeldeKeukens,AantalGedeeldeDouchen")] Gebouw gebouw)
        {
            if (id != gebouw.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.Append(gebouw.Straat);
                    stringBuilder.Append(" ");
                    stringBuilder.Append(gebouw.Huisnummer);
                    gebouw.Adres = stringBuilder.ToString();
                    _context.Update(gebouw);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!GebouwExists(gebouw.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(gebouw);
        }

        // GET: Gebouw/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var gebouw = await _context.Gebouwen
                .FirstOrDefaultAsync(m => m.Id == id);
            if (gebouw == null)
            {
                return NotFound();
            }

            return View(gebouw);
        }

        // POST: Gebouw/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var gebouw = await _context.Gebouwen.FindAsync(id);
            _context.Gebouwen.Remove(gebouw);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool GebouwExists(int id)
        {
            return _context.Gebouwen.Any(e => e.Id == id);
        }
    }
}