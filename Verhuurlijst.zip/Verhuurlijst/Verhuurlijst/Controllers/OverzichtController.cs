﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Verhuurlijst.Core;
using Verhuurlijst.Models;

namespace Verhuurlijst.Controllers
{
    public class OverzichtController : Controller
    {
        private readonly DatabaseContext _databaseContext;

        public OverzichtController(DatabaseContext database)
        {
            _databaseContext = database;
        }
        public async Task<IActionResult> Index()
        {            var gebouwen = _databaseContext.Gebouwen.ToList();
            foreach (var gebouw in gebouwen)
            {
                gebouw.AantalVrijeKamers = 0;
                gebouw.AantalKamers = 0;
                foreach (var kamer in _databaseContext.Kamers)
                {
                    if (kamer.GebouwId == gebouw.Id)
                    {
                        gebouw.KamersPerGebouw.Add(kamer);
                        gebouw.AantalKamers += 1;
                        if (kamer.IsVerhuurd == false)
                        {
                            gebouw.AantalVrijeKamers += 1;
                        }
                    }
                }
            }
            await _databaseContext.SaveChangesAsync();
            return View(await _databaseContext.Gebouwen.ToListAsync());
        }
    }
}
