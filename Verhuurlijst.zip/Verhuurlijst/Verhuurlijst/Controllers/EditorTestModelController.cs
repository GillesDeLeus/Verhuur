﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataTables;
using Microsoft.AspNetCore;
using Verhuurlijst.Models;
using System.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data.Common;
using Microsoft.AspNetCore.Hosting;

namespace Verhuurlijst.Controllers
{
    public class EditorTestModelController : Controller 
    {
        [HttpGet, HttpPost]
        public ActionResult Index()
        {
            var dbType = Environment.GetEnvironmentVariable("DBTYPE");
            var dbConnection = Environment.GetEnvironmentVariable("DBCONNECTION");

            using (var db = new Database(dbType, dbConnection))
            {
                var response = new Editor(db, "users")
                    .Model<Kamer>()
                    .Field(new Field("image")
                        .SetFormatter((val, data) => (string)val == "" ? 0 : 1)
                    )
                    .Process(Request)
                    .Data();

                return Json(response);
            }
        }
    }
}
