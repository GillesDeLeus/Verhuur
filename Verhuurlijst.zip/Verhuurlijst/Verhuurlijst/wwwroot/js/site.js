﻿var showInPopup = async (url, title) => {
    jQuery.ajax({
        type: "GET",
        url: url,
        success: function (response) {
            jQuery("#exampleModal .modal-body").html(response);
            jQuery("#exampleModal .modal-title").html(title);
            jQuery("#exampleModal").modal('show');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
            console.log("fail")
        }
    })
}

jQueryAjaxPost = form => {
    try {
        jQuery.ajax({
            type: 'POST',
            url: form.action,
            data: new FormData(form),
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.isValid) {
                    jQuery('#view-All').html(res.html)
                    jQuery("#exampleModal .modal-body").html("");
                    jQuery("#exampleModal .modal-title").html("");
                    jQuery("#exampleModal").modal('hide');
                    var table = jQuery('#tab').DataTable({
                        dom: 'QBfrtip',
                        buttons: ['excel', 'copy', 'print',
                            {
                                extend: 'colvis',
                                className: 'Zichtbaarheid kolommen'
                            },
                            {
                                extend: 'searchPanes',
                                config: {
                                    cascadePanes: true
                                }
                            }],
                        select: {
                            items: 'cell'
                        },
                        fixedHeader: true,
                        responsive: true,
                        keys: true
                    });
                }
                else
                    jQuery('#exampleModal .modal-body').html(res.html);
            },
            error: function (err) {
                console.log(err)
            }
        })
        //to prevent default form submit event
        return false;
    } catch (ex) {
        console.log(ex)
    }
}