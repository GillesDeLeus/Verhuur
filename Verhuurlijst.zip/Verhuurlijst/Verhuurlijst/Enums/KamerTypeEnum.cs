﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Verhuurlijst.Models
{
    public enum KamerTypeEnum
    {
        Kamer,
        KamerEigenSanitair,
        KamerEigenKitchenette,
        Studio,
        Flat,
        App_1Slaapkamer,
        App_2Slaapkamer,
        App_3Slaapkamer,
        App_4Slaapkamer
    }
}
