﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Verhuurlijst.Migrations
{
    public partial class toevoegenattributenaankamers : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Begindatum",
                table: "Kamers",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ContractStatus",
                table: "Kamers",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Einddatum",
                table: "Kamers",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Huurder",
                table: "Kamers",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "KamerType",
                table: "Kamers",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "VerhuurStatus",
                table: "Kamers",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Begindatum",
                table: "Kamers");

            migrationBuilder.DropColumn(
                name: "ContractStatus",
                table: "Kamers");

            migrationBuilder.DropColumn(
                name: "Einddatum",
                table: "Kamers");

            migrationBuilder.DropColumn(
                name: "Huurder",
                table: "Kamers");

            migrationBuilder.DropColumn(
                name: "KamerType",
                table: "Kamers");

            migrationBuilder.DropColumn(
                name: "VerhuurStatus",
                table: "Kamers");
        }
    }
}
