﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Verhuurlijst.Migrations
{
    public partial class aanpassingenkamerengebouwen : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Adres",
                table: "Kamers",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Adres",
                table: "Kamers");
        }
    }
}
