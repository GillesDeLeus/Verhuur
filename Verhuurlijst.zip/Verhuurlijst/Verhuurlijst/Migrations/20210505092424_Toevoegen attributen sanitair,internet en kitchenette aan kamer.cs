﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Verhuurlijst.Migrations
{
    public partial class Toevoegenattributensanitairinternetenkitchenetteaankamer : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "VerhuurStatus",
                table: "Kamers");

            migrationBuilder.AddColumn<bool>(
                name: "InternetaansluitingOpKamer",
                table: "Kamers",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "KitchenetteOpKamer",
                table: "Kamers",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "SanitairOpKamer",
                table: "Kamers",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "InternetaansluitingOpKamer",
                table: "Kamers");

            migrationBuilder.DropColumn(
                name: "KitchenetteOpKamer",
                table: "Kamers");

            migrationBuilder.DropColumn(
                name: "SanitairOpKamer",
                table: "Kamers");

            migrationBuilder.AddColumn<string>(
                name: "VerhuurStatus",
                table: "Kamers",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
