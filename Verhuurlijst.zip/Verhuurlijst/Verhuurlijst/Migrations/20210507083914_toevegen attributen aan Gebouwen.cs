﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Verhuurlijst.Migrations
{
    public partial class toevegenattributenaanGebouwen : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "AantalGedeeldeDouchen",
                table: "Gebouwen",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "AantalGedeeldeKeukens",
                table: "Gebouwen",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<bool>(
                name: "Fietsenstalling",
                table: "Gebouwen",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AantalGedeeldeDouchen",
                table: "Gebouwen");

            migrationBuilder.DropColumn(
                name: "AantalGedeeldeKeukens",
                table: "Gebouwen");

            migrationBuilder.DropColumn(
                name: "Fietsenstalling",
                table: "Gebouwen");
        }
    }
}
