﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Verhuurlijst.Migrations
{
    public partial class addedVrijeKamers : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "AantalKamers",
                table: "Gebouwen",
                newName: "AantalVrijeKamers");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "AantalVrijeKamers",
                table: "Gebouwen",
                newName: "AantalKamers");
        }
    }
}
