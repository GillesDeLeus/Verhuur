﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Verhuurlijst.Migrations
{
    public partial class initialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Werknemers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Geboortedag = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsWerknemer = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Werknemers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Gebouwen",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Straat = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Huisnummer = table.Column<int>(type: "int", nullable: false),
                    Gemeente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    VerantwoordelijkeId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Gebouwen", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Gebouwen_Werknemers_VerantwoordelijkeId",
                        column: x => x.VerantwoordelijkeId,
                        principalTable: "Werknemers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Kamers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Kamernummer = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsVerhuurd = table.Column<bool>(type: "bit", nullable: false),
                    IsBemeubeld = table.Column<bool>(type: "bit", nullable: false),
                    HuurPrijs = table.Column<double>(type: "float", nullable: false),
                    VasteKosten = table.Column<double>(type: "float", nullable: false),
                    Waarborg = table.Column<double>(type: "float", nullable: false),
                    GebouwId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Kamers", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Kamers_Gebouwen_GebouwId",
                        column: x => x.GebouwId,
                        principalTable: "Gebouwen",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Huurders",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Geboortedag = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsHuurder = table.Column<bool>(type: "bit", nullable: false),
                    HuurtKamerId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Huurders", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Huurders_Kamers_HuurtKamerId",
                        column: x => x.HuurtKamerId,
                        principalTable: "Kamers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Gebouwen_VerantwoordelijkeId",
                table: "Gebouwen",
                column: "VerantwoordelijkeId");

            migrationBuilder.CreateIndex(
                name: "IX_Huurders_HuurtKamerId",
                table: "Huurders",
                column: "HuurtKamerId");

            migrationBuilder.CreateIndex(
                name: "IX_Kamers_GebouwId",
                table: "Kamers",
                column: "GebouwId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Huurders");

            migrationBuilder.DropTable(
                name: "Kamers");

            migrationBuilder.DropTable(
                name: "Gebouwen");

            migrationBuilder.DropTable(
                name: "Werknemers");
        }
    }
}
