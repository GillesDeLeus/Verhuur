﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Verhuurlijst.Migrations
{
    public partial class verwijderentabelhuurdersenwerknemers : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Gebouwen_Werknemers_VerantwoordelijkeId",
                table: "Gebouwen");

            migrationBuilder.DropTable(
                name: "Huurders");

            migrationBuilder.DropTable(
                name: "Werknemers");

            migrationBuilder.DropIndex(
                name: "IX_Gebouwen_VerantwoordelijkeId",
                table: "Gebouwen");

            migrationBuilder.DropColumn(
                name: "VerantwoordelijkeId",
                table: "Gebouwen");

            migrationBuilder.AddColumn<string>(
                name: "Verantwoordelijke",
                table: "Gebouwen",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Verantwoordelijke",
                table: "Gebouwen");

            migrationBuilder.AddColumn<int>(
                name: "VerantwoordelijkeId",
                table: "Gebouwen",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Huurders",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Geboortedag = table.Column<DateTime>(type: "datetime2", nullable: false),
                    HuurtKamerId = table.Column<int>(type: "int", nullable: true),
                    IsHuurder = table.Column<bool>(type: "bit", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Huurders", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Huurders_Kamers_HuurtKamerId",
                        column: x => x.HuurtKamerId,
                        principalTable: "Kamers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Werknemers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Geboortedag = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsWerknemer = table.Column<bool>(type: "bit", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Werknemers", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Gebouwen_VerantwoordelijkeId",
                table: "Gebouwen",
                column: "VerantwoordelijkeId");

            migrationBuilder.CreateIndex(
                name: "IX_Huurders_HuurtKamerId",
                table: "Huurders",
                column: "HuurtKamerId");

            migrationBuilder.AddForeignKey(
                name: "FK_Gebouwen_Werknemers_VerantwoordelijkeId",
                table: "Gebouwen",
                column: "VerantwoordelijkeId",
                principalTable: "Werknemers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
